import dotenv from "dotenv";
//load all the environment variables in application
dotenv.config();

